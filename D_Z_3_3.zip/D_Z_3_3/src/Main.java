import java.util.Arrays;

public class Main {
    public static void main(String[] args) {
        for (int i = 1; i <= 10; i = i + 1) {
            System.out.println("Hello Junior " + i);
            for (int j = 1; j < 5; j++) {
                System.out.println("Hello Junior" + i);


            }
        }
        String[] cars = new String[200];
        cars[0] = "Cars001";
        cars[1] = "Cars002";
        cars[2] = "Cars003";
        cars[3] = "Cars004";
        cars[4] = "Cars005";
        cars[5] = "Cars006";
        cars[6] = "Cars007";
        System.out.println(Arrays.toString(cars));

        String[] Cars = new String[200];
        for (int i = 0; i < cars.length; i++) {
            cars[i] = "cars00" + (i + 1);
        }
        System.out.println(Arrays.toString(cars));

        for (int i = 1; i < 24; i++) {
            System.out.println("Hello Bro" + i);

        }
    }
}